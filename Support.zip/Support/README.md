# Prime Messaging Website

Готовый адаптивный сайт для Prime Messaging (в стиле структуры WhatsApp), без кнопок Login и Download.

## Что внутри

- `index.html` — основная страница
- `styles.css` — визуальный стиль и адаптив
- `script.js` — интерактив (мобильное меню, анимации, FAQ, форма)
- `prime-favicon.svg` — favicon

## Быстрый запуск

Откройте `index.html` в браузере.

Для локального сервера (рекомендуется):

```bash
python3 -m http.server 8080
```

После этого откройте:

- `http://localhost:8080`

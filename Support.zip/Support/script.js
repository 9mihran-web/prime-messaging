const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
const navLinks = document.querySelectorAll('.main-nav a');

if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });

  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
    });
  });

  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const clickedInsideMenu = target.closest('.main-nav') || target.closest('.menu-toggle');
    if (!clickedInsideMenu) {
      nav.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

const revealItems = document.querySelectorAll('.section-reveal');

if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.15 }
  );

  revealItems.forEach((item) => revealObserver.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add('is-visible'));
}

const counters = document.querySelectorAll('[data-count]');

function animateCounter(element) {
  const target = Number(element.dataset.count || 0);
  const duration = 1200;
  const startTime = performance.now();

  const updateCounter = (now) => {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.floor(target * eased);
    element.textContent = String(current);

    if (progress < 1) {
      requestAnimationFrame(updateCounter);
    } else {
      element.textContent = String(target);
    }
  };

  requestAnimationFrame(updateCounter);
}

if ('IntersectionObserver' in window && counters.length > 0) {
  const counterObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.6 }
  );

  counters.forEach((counter) => counterObserver.observe(counter));
} else {
  counters.forEach((counter) => {
    counter.textContent = counter.dataset.count || '0';
  });
}

const accordionButtons = document.querySelectorAll('.accordion-item button');

accordionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const item = button.closest('.accordion-item');
    if (!item) return;

    const content = item.querySelector('.accordion-content');
    const isOpen = item.classList.contains('open');

    document.querySelectorAll('.accordion-item.open').forEach((openItem) => {
      openItem.classList.remove('open');
      const openButton = openItem.querySelector('button');
      const openContent = openItem.querySelector('.accordion-content');
      if (openButton) openButton.setAttribute('aria-expanded', 'false');
      if (openContent) openContent.style.maxHeight = '';
    });

    if (!isOpen) {
      item.classList.add('open');
      button.setAttribute('aria-expanded', 'true');
      if (content instanceof HTMLElement) {
        content.style.maxHeight = `${content.scrollHeight}px`;
      }
    }
  });
});

const contactForm = document.querySelector('.contact-form');
const formStatus = document.querySelector('.form-status');

if (contactForm instanceof HTMLFormElement && formStatus instanceof HTMLElement) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();

    if (!contactForm.checkValidity()) {
      formStatus.className = 'form-status error';
      formStatus.textContent = 'Проверьте поля формы: заполните обязательные данные корректно.';
      contactForm.reportValidity();
      return;
    }

    formStatus.className = 'form-status';
    formStatus.textContent = 'Отправка...';

    const submitButton = contactForm.querySelector('button[type="submit"]');
    if (submitButton instanceof HTMLButtonElement) {
      submitButton.disabled = true;
      submitButton.style.opacity = '0.7';
    }

    window.setTimeout(() => {
      formStatus.className = 'form-status success';
      formStatus.textContent = 'Заявка отправлена. Мы свяжемся с вами в ближайшее время.';
      contactForm.reset();

      if (submitButton instanceof HTMLButtonElement) {
        submitButton.disabled = false;
        submitButton.style.opacity = '';
      }
    }, 700);
  });
}

const yearElement = document.getElementById('year');
if (yearElement) {
  yearElement.textContent = String(new Date().getFullYear());
}
